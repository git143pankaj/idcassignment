function fetchData() {
    //console.log("I am wroking")
    fetch('https://reqres.in/api/users').then(response => {
        //console.log(response);
        if (!response.ok) {
            throw Error('ERROR')
        }
        return response.json();
    }).then(getData => {
        console.log(getData.data);
        const html = getData.data.map(user => {
            return `
            <div class="service-box">
            <p><img src="${user.avatar}" alt="${user.first_name}"/></p>
        	<p>Name : ${user.first_name} ${user.last_name}</p>
        	<p>Email : ${user.email}</p>
        	</div>

        	`
        }).join('');
        document.querySelector('.service-container').insertAdjacentHTML("afterbegin", html);
    }).catch(error => {
        console.log(error);
    })
}
fetchData();



// for psot request and get request

function psotData() {
    fetch('https://reqres.in/api/users', {
        method: 'POST',
        headers: {
            'content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: "morpheus",
            job: "leader"
        })
    }).then(response => {
        if (!response.ok) {
            throw Error("ERROR OCCORED")
        }
        return response.json();
    }).then(getData => {
        console.log(getData);
    }).catch(error => {
        console.log(error);
    })
}
psotData();


